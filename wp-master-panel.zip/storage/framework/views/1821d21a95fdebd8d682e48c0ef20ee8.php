<?php if (isset($component)) { $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $attributes; } ?>
<?php $component = App\View\Components\BackendLayout::resolve(['title' => 'Create Role & Permissions'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BackendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            .permission-card {
                border: 1px solid #ddd;
                border-radius: 6px;
            }

            .permission-list {
                padding-left: 10px;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <div class="row mt-4">
        <div class="col-md-12">
            <form action="<?php echo e(route('roles.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-body">
                        <!-- Role Name -->
                        <div class="mb-3">
                            <label class="form-label"><b>Role Name</b></label>
                            <input type="text" name="name" class="form-control" placeholder="Enter Role Name" required>
                        </div>

                        <!-- Select All Permissions -->
                        <div class="form-check mb-3">
                            <input type="checkbox" id="select_all" class="form-check-input">
                            <label for="select_all" class="form-check-label"><b>Select All Permissions</b></label>
                        </div>

                        <!-- Permissions Grid -->
                        <div class="row">
                            <?php $__currentLoopData = $groupedPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="card border rounded p-2 mb-3 permission-card">
                                        <div class="card-header bg-light">
                                            <input type="checkbox" class="form-check-input module_check" id="module-<?php echo e($module); ?>">
                                            <label for="module-<?php echo e($module); ?>" class="form-check-label mb-0 fw-bold">
                                                <?php echo e(ucfirst($module)); ?> (<?php echo e(count($permissions)); ?>)
                                            </label>
                                        </div>
                                        <div class="card-body p-2 permission-list">
                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-check mb-1">
                                                    <input type="checkbox" name="permissions[]"
                                                        value="<?php echo e($permission->name); ?>"
                                                        class="form-check-input permission_item"
                                                        id="perm-<?php echo e($permission->name); ?>">
                                                    <label for="perm-<?php echo e($permission->name); ?>" class="form-check-label">
                                                        <?php echo e(ucfirst(str_replace('-', ' ', $permission->name))); ?>

                                                    </label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-success mt-3">
                            <i class="fas fa-save me-2"></i>Save Role
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            $(document).ready(function() {
                const selectedPermissions = [];

                // Select All
                $('#select_all').on('change', function() {
                    const checked = $(this).prop('checked');
                    $('.module_check, .permission_item').prop('checked', checked);
                });

                // Module select/deselect
                $('.module_check').on('change', function() {
                    const card = $(this).closest('.permission-card');
                    const checked = $(this).prop('checked');
                    card.find('.permission_item').prop('checked', checked);
                    updateSelectAll();
                });

                // Individual permission check
                $('.permission_item').on('change', function() {
                    const card = $(this).closest('.permission-card');
                    const allChecked = card.find('.permission_item').length === card.find(
                        '.permission_item:checked').length;
                    card.find('.module_check').prop('checked', allChecked);
                    updateSelectAll();
                });

                function updateSelectAll() {
                    const total = $('.permission_item').length;
                    const checked = $('.permission_item:checked').length;
                    const selectAll = $('#select_all');
                    if (checked === total) selectAll.prop('checked', true).prop('indeterminate', false);
                    else if (checked > 0) selectAll.prop('checked', false).prop('indeterminate', true);
                    else selectAll.prop('checked', false).prop('indeterminate', false);
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $attributes = $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $component = $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?><?php /**PATH D:\xampp8\htdocs\wp-master-panel\resources\views/backend/roles/create.blade.php ENDPATH**/ ?>