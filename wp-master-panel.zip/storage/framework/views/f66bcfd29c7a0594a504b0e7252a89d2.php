<?php if (isset($component)) { $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $attributes; } ?>
<?php $component = App\View\Components\BackendLayout::resolve(['title' => 'Orders'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BackendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <h1 class="page-title fw-semibold fs-18 mb-0">Woo Commerce Live</h1>
        <div class="ms-md-1 ms-0">
            <nav>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Orders</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Orders Table -->
    <div class="card custom-card">
        <div class="card-body p-0">
            <div class="card-header justify-content-between">
                <div class="card-title">Order List</div>
                <button type="button" id="sync-btn" class="btn btn-primary btn-sm">
                    <i class="fa fa-sync-alt me-1"></i> Sync Now
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Items</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <strong>#<?php echo e($order['number'] ?? $order['id']); ?></strong><br>
                                    <small class="text-muted">ID: <?php echo e($order['id']); ?></small>
                                </td>
                                <td>
                                    <?php echo e($order['billing']['first_name']); ?> <?php echo e($order['billing']['last_name']); ?><br>
                                    <small class="text-muted"><i class="fa fa-phone me-1"></i><?php echo e($order['billing']['phone'] ?? 'N/A'); ?></small><br>
                                    <small class="text-muted"><i class="fa fa-envelope me-1"></i><?php echo e($order['billing']['email'] ?? 'N/A'); ?></small>
                                </td>
                                <td>
                                    <?php echo e(\Carbon\Carbon::parse($order['date_created'])->format('M d, Y')); ?><br>
                                    <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($order['date_created'])->format('g:i A')); ?></small>
                                </td>
                                <td>
                                    <strong class="text-success">$<?php echo e(number_format($order['total'], 2)); ?></strong><br>
                                    <small class="text-muted"><?php echo e(strtoupper($order['currency'])); ?></small>
                                </td>
                                <td>
                                    <?php
                                        $color = match($order['status']) {
                                            'completed' => 'success',
                                            'processing' => 'info',
                                            'pending' => 'warning',
                                            'cancelled' => 'danger',
                                            default => 'secondary',
                                        };
                                    ?>
                                    <span class="badge bg-<?php echo e($color); ?>"><?php echo e(ucfirst($order['status'])); ?></span>
                                </td>
                                <td>
                                    <ul class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $order['line_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><i class="fa fa-cube me-1"></i><?php echo e($item['name']); ?> × <?php echo e($item['quantity']); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </td>
                                <td>
                                    <div class="hstack gap-2 fs-15">
                                        <a href="javascript:void(0);" class="btn btn-icon btn-sm btn-success-transparent rounded-pill"><i class="ri-download-2-line"></i></a>
                                        <a href="javascript:void(0);" class="btn btn-icon btn-sm btn-info-transparent rounded-pill"><i class="ri-edit-line"></i></a>
                                        <a href="javascript:void(0);" class="btn btn-icon btn-sm btn-danger-transparent rounded-pill"><i class="ri-delete-bin-line"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <i class="fa fa-inbox fa-2x text-muted mb-2"></i>
                                    <div>No orders found</div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination -->
        <div class="card-footer d-flex justify-content-center">
            <?php echo $__env->make('backend.pagination.paginate', ['paginator' => $orders], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
    <script>
        document.getElementById('sync-btn').addEventListener('click', function() {
            this.disabled = true;
            this.innerHTML = '<i class="fa fa-spinner fa-spin me-1"></i> Syncing...';

            fetch('<?php echo e(route('wp.orders-sync')); ?>', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                location.reload();
            })
            .catch(err => alert('Error: ' + err.message))
            .finally(() => {
                this.disabled = false;
                this.innerHTML = '<i class="fa fa-sync-alt me-1"></i> Sync Now';
            });
        });
    </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $attributes = $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $component = $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8\htdocs\wp-master-panel\resources\views/backend/orders/wp-orders-live.blade.php ENDPATH**/ ?>