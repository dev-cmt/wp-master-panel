<?php if (isset($component)) { $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $attributes; } ?>
<?php $component = App\View\Components\BackendLayout::resolve(['title' => 'Dashboard'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BackendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Start::page-header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div>
            <p class="fw-semibold fs-18 mb-0">Welcome back, <?php echo e(Auth::user()->name); ?>!</p>
            <span class="fs-semibold text-muted">Track your sales activity, leads and deals here.</span>
        </div>
        <div class="ms-md-1 ms-0">
            <nav>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- End::page-header -->

    <!-- Start::row-1: Revenues / Staff / Customers / Products -->
    <div class="row">
        <?php
            $totalRevenues  = DB::table('orders')->sum('total');
            $totalStaffs    = DB::table('users')->where('status', true)->count();
            $totalCustomers = DB::table('users')->where('status', false)->count();
            $totalProducts  = DB::table('products')->count();

            $cards = [
                [
                    'title' => 'Total Revenues',
                    'value' => '৳ ' . number_format($totalRevenues),
                    'icon'  => 'bi-currency-dollar',
                    'bg'    => 'bg-primary-transparent text-primary'
                ],
                [
                    'title' => 'Total Staffs',
                    'value' => $totalStaffs,
                    'icon'  => 'bi-people-fill',
                    'bg'    => 'bg-secondary-transparent text-secondary'
                ],
                [
                    'title' => 'Total Customers',
                    'value' => $totalCustomers,
                    'icon'  => 'bi-person-lines-fill',
                    'bg'    => 'bg-success-transparent text-success'
                ],
                [
                    'title' => 'Total Products',
                    'value' => $totalProducts,
                    'icon'  => 'bi-box-seam',
                    'bg'    => 'bg-info-transparent text-info'
                ],
            ];
        ?>

        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-md-6">
                <div class="card custom-card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-top justify-content-between">
                            <div class="flex-fill">
                                <p class="mb-0 text-muted"><?php echo e($card['title']); ?></p>
                                <span class="fs-5 fw-semibold"><?php echo e($card['value']); ?></span>
                            </div>
                            <div>
                                <span class="avatar avatar-md avatar-rounded <?php echo e($card['bg']); ?> fs-18">
                                    <i class="bi <?php echo e($card['icon']); ?> fs-16"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- End::row-1 -->

    <!-- Start::row-2: Orders as col-2 cards with icons -->
    <div class="row">
        <?php
            // Get counts grouped by numeric status
            $orderCounts = DB::table('orders')
                ->select('status', DB::raw('COUNT(*) as total'))
                ->groupBy('status')
                ->pluck('total', 'status')
                ->toArray();

            // Status mapping for dashboard cards
            $statusCards = [
                0 => ['title' => 'Hold', 'icon' => 'bi-pause-circle', 'color' => 'bg-info'],
                1 => ['title' => 'Delivered', 'icon' => 'bi-check2-circle', 'color' => 'bg-success'],
                2 => ['title' => 'Processing', 'icon' => 'bi-arrow-repeat', 'color' => 'bg-secondary'],
                3 => ['title' => 'Pending Payment', 'icon' => 'bi-clock', 'color' => 'bg-warning'],
                4 => ['title' => 'Cancelled', 'icon' => 'bi-x-circle', 'color' => 'bg-danger'],
                5 => ['title' => 'Pending Invoice', 'icon' => 'bi-file-earmark-text', 'color' => 'bg-primary'],
                6 => ['title' => 'On Delivery', 'icon' => 'bi-bicycle', 'color' => 'bg-primary'],
                7 => ['title' => 'Pending Return', 'icon' => 'bi-arrow-counterclockwise', 'color' => 'bg-warning'],
                8 => ['title' => 'Courier', 'icon' => 'bi-truck', 'color' => 'bg-info'],
                9 => ['title' => 'No Response', 'icon' => 'bi-question-circle', 'color' => 'bg-success'],
                10 => ['title' => 'Invoiced', 'icon' => 'bi-file-earmark-check', 'color' => 'bg-success'],
                11 => ['title' => 'Return', 'icon' => 'bi-reply-all', 'color' => 'bg-danger'],
                12 => ['title' => 'Incomplete', 'icon' => 'bi-dash-circle', 'color' => 'bg-warning'],
                13 => ['title' => 'Confirmed', 'icon' => 'bi-check-circle', 'color' => 'bg-success'],
                14 => ['title' => 'Stock Out', 'icon' => 'bi-box-seam', 'color' => 'bg-danger'],
                15 => ['title' => 'Partial Delivery', 'icon' => 'bi-arrow-right-square', 'color' => 'bg-info'],
                16 => ['title' => 'Lost', 'icon' => 'bi-exclamation-circle', 'color' => 'bg-secondary'],
            ];

            $totalOrders = DB::table('orders')->count();
        ?>

        <!-- Total Orders Card -->
        <div class="col-lg-2 col-md-3 col-sm-4">
            <a href="<?php echo e(route('orders.index')); ?>" class="text-decoration-none text-dark">
                <div class="card custom-card mb-2">
                    <div class="card-body p-2">
                        <div class="d-flex align-items-top">
                            <div class="me-3">
                                <span class="avatar avatar-lg bg-primary">
                                    <i class="bi bi-stack fs-16"></i>
                                </span>
                            </div>
                            <div>
                                <p class="mb-1 text-muted">Total Orders</p>
                                <h5 class="mb-0 fw-semibold"><?php echo e($totalOrders); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <!-- Status-wise Cards -->
        <?php $__currentLoopData = $statusCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-md-3 col-sm-4">
                <a href="<?php echo e(route('orders.index', ['status' => $status])); ?>" class="text-decoration-none text-dark">
                    <div class="card custom-card mb-2">
                        <div class="card-body p-2">
                            <div class="d-flex align-items-top">
                                <div class="me-3">
                                    <span class="avatar avatar-lg <?php echo e($data['color']); ?>">
                                        <i class="bi <?php echo e($data['icon']); ?> fs-16"></i>
                                    </span>
                                </div>
                                <div>
                                    <p class="mb-1 text-muted"><?php echo e($data['title']); ?></p>
                                    <h5 class="mb-0 fw-semibold"><?php echo e($orderCounts[$status] ?? 0); ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- End::row-2 -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $attributes = $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $component = $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8\htdocs\wp-master-panel\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>