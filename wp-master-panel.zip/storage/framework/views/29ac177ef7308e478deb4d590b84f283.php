<?php if (isset($component)) { $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $attributes; } ?>
<?php $component = App\View\Components\BackendLayout::resolve(['title' => 'Store'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BackendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <h1 class="page-title fw-semibold fs-18 mb-0">Store Management</h1>
        <div class="ms-md-1 ms-0">
            <nav>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Stores</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Store List -->
    <div class="card custom-card">
        <div class="card-header justify-content-between">
            <div class="card-title">Store List</div>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#createStoreModal">
                <i class="ri-add-line me-1"></i>Add Store
            </button>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table text-nowrap table-hover">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>Prefix</th>
                            <th>Base URL</th>
                            <th>API Key</th>
                            <th>API Secret</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($stores->firstItem() + $key); ?></td>
                            <td><?php echo e($store->name); ?></td>
                            <td><?php echo e($store->prefix); ?></td>
                            <td><?php echo e($store->base_url); ?></td>
                            <td><?php echo e($store->api_key); ?></td>
                            <td><?php echo e($store->api_secret); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($store->status ? 'success' : 'danger'); ?>-transparent">
                                    <?php echo e($store->status ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td>
                                <div class="btn-list">
                                    <button type="button" class="btn btn-warning-light btn-sm edit-store"
                                        data-id="<?php echo e($store->id); ?>"
                                        data-name="<?php echo e($store->name); ?>"
                                        data-prefix="<?php echo e($store->prefix); ?>"
                                        data-base_url="<?php echo e($store->base_url); ?>"
                                        data-api_key="<?php echo e($store->api_key); ?>"
                                        data-api_secret="<?php echo e($store->api_secret); ?>"
                                        data-ep_order_store="<?php echo e($store->ep_order_store); ?>"
                                        data-ep_order_update="<?php echo e($store->ep_order_update); ?>"
                                        data-ep_order_status="<?php echo e($store->ep_order_status); ?>"
                                        data-ep_order_delete="<?php echo e($store->ep_order_delete); ?>"
                                        data-status="<?php echo e($store->status); ?>"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editStoreModal">
                                        <i class="ri-pencil-line"></i>
                                    </button>

                                    <form action="<?php echo e(route('stores.destroy', $store->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger-light btn-sm" onclick="return confirm('Delete this store?')">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="7" class="text-center">No stores found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-center mt-3">
                <?php echo e($stores->links()); ?>

            </div>
        </div>
    </div>

    <!-- Create Store Modal -->
    <div class="modal fade" id="createStoreModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="<?php echo e(route('stores.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h6 class="modal-title">Add New Store</h6>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body row g-3">
                        <?php echo $__env->make('backend.stores.__form', ['store' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Create Store</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Store Modal -->
    <div class="modal fade" id="editStoreModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="<?php echo e(route('stores.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h6 class="modal-title">Edit Store</h6>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body row g-3">
                        <input type="hidden" id="edit_id" name="id">
                        <?php echo $__env->make('backend.stores.__form', ['store' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update Store</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->startPush('js'); ?>
<script>
    $('#createStoreModal').on('show.bs.modal', function (e) {
        const form = $(this).find('form')[0];
        form.reset();

        // Optional: clear validation messages (if any)
        $(this).find('.is-invalid').removeClass('is-invalid');
        $(this).find('.invalid-feedback').remove();
    });
</script>

<script>
    $(document).on('click', '.edit-store', function() {
        $('#edit_id').val($(this).data('id'));
        $('input[name="name"]').val($(this).data('name'));
        $('input[name="prefix"]').val($(this).data('prefix'));
        $('input[name="base_url"]').val($(this).data('base_url'));
        $('input[name="api_key"]').val($(this).data('api_key'));
        $('input[name="api_secret"]').val($(this).data('api_secret'));
        $('input[name="ep_order_store"]').val($(this).data('ep_order_store'));
        $('input[name="ep_order_update"]').val($(this).data('ep_order_update'));
        $('input[name="ep_order_status"]').val($(this).data('ep_order_status'));
        $('input[name="ep_order_delete"]').val($(this).data('ep_order_delete'));
        $('select[name="status"]').val($(this).data('status'));
    });
</script>
<?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $attributes = $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $component = $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8\htdocs\wp-master-panel\resources\views/backend/stores/index.blade.php ENDPATH**/ ?>